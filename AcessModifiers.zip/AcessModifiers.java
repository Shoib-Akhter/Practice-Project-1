package practicephase1;

public class AcessModifiers {
	private String name;

    // getter method
    public String getName() {
        return this.name;
    }
    // setter method
    public void setName(String name) {
        this.name= name;
            
	}
    //using default
    void display() {
    	String str = "Hi Iam Default access modifier means without mentioning any name to access specifier";
    	System.out.println(str);
    }
    //using protected
    protected String str2 = "Hi iam Proctected modifier";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 AcessModifiers  d = new AcessModifiers();
		  //String str = "Hi Iam Default access modifier means without mentioning any name to access specifier";

	        // access the private variable using the getter and setter
	        d.setName("Private Access Modifier");
	        System.out.println(d.getName());

			d.display();
			System.out.println(d.str2);
	        
	}

}


